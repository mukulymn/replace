from openpyxl import load_workbook
from openpyxl.utils import get_column_letter
from collections import defaultdict

def def_value():
    return None

wb = load_workbook('./MX_META.xlsx')

print(wb.sheetnames)

ws_mxmeta = wb['Meta']
ws_map = wb['Map']

#print(ws_mxmeta['A1'].value,ws_mxmeta['B1'].value)

ATTR_TYPE='type'
ATTR_SEQ = 'sequence'
mx_Obj_attr = defaultdict(def_value)



# first row is for header
current_row = 1

while True:
    current_row += 1
    mx_obj = ws_mxmeta[get_column_letter(1)+str(current_row)].value
    mx_attr = ws_mxmeta[get_column_letter(2)+str(current_row)].value
    mx_type = ws_mxmeta[get_column_letter(3)+str(current_row)].value
    mx_seq = ws_mxmeta[get_column_letter(4)+str(current_row)].value
    
    if not mx_obj:
        break
    
    obj_dict = mx_Obj_attr.get(mx_obj)

    if obj_dict:
        obj_dict[mx_attr] = {ATTR_TYPE:mx_type,ATTR_SEQ:mx_seq}
    else:        
        mx_Obj_attr[mx_obj] = {mx_attr:{ATTR_TYPE:mx_type,ATTR_SEQ:mx_seq}}

    
    
    #print(ws_mxmeta[get_column_letter(1)+str(current_row)].value,
    #      ws_mxmeta[get_column_letter(2)+str(current_row)].value,
    #      ws_mxmeta[get_column_letter(3)+str(current_row)].value,
    #      ws_mxmeta[get_column_letter(4)+str(current_row)].value)
    

#print(mx_Obj_attr)

for dict_object in mx_Obj_attr.keys():
    print(dict_object)
    dict_atrr = mx_Obj_attr[dict_object]    
    list_attr = dict_atrr.keys()
    attr_type_dict = {}
    attr_seq_dict = {}
    
    for attr in list_attr:
        type = dict_atrr[attr][ATTR_TYPE]
        sequence = dict_atrr[attr][ATTR_SEQ]
        attr_type_dict[attr] = type
        if sequence:
            attr_seq_dict[attr] = sequence
     
    print(attr_type_dict)
    print(attr_seq_dict)
    master_insert = f"INSERT INTO {dict_object} ({','.join(list_attr)}) values()"
    print(master_insert)
    
wb.close()
