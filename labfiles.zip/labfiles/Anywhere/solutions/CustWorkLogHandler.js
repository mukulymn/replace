define("custom/handlers/CustWorkLogHandler", 
	  ["dojo/_base/declare", "dojo/_base/lang",
	   "platform/handlers/_ApplicationHandlerBase",
	   "application/business/SynonymDomain"],
function(declare, lang, ApplicationHandlerBase, SynonymDomain) {

return declare( ApplicationHandlerBase, {
		
  initNewWorkLogEntry: function(eventContext) {
			
    var currWorkLog = eventContext.getCurrentRecord();
    if(currWorkLog) {
      var domainlogtype = eventContext.application.getResource("domainlogtype");
      var newVal = SynonymDomain.resolveToDefaultExternal(domainlogtype, 'WORK');
      currWorkLog.set("logtype", newVal);
    }
  }
});
});
