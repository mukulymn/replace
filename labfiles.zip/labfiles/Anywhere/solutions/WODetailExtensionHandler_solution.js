define("custom/handlers/WODetailExtensionHandler", 
	   		[ "dojo/_base/declare",
	     		"dojo/_base/lang",
	     		"platform/handlers/_ApplicationHandlerBase",	  
	     		"application/handlers/CommonHandler"],
function(declare, lang, ApplicationHandlerBase, CommonHandler) {
	
	return declare( [ApplicationHandlerBase],  {
		
		
		handleConditionalRisk: function(eventContext){
			// This is an render handler for the WO Details View
			// to handle changes made to the worktype field and show the Risk field
			
			// current workOrder is on the eventContext
			var currWO = CommonHandler._getAdditionalResource(eventContext,"workOrder").getCurrentRecord();
			var worktype = currWO.get('worktype');
	
			// The current risk field is on the eventContext
			// to show the risk field if worktype equals to EMERGENCY
			eventContext.setDisplay(worktype && worktype == "EM");
				
			// Hook a listener to watch the worktype attribute, 
			// and make the risk field appear when worktype is Emergency
			if (!eventContext.hasResourceWatch("workTypeWatch")) {
			    eventContext.addResourceWatchHandle(currWO.watch('worktype', 
					lang.hitch(this, function(attrName, oldValue, newValue)
								{
									eventContext.setDisplay(newValue && newValue=="EM"); 
								}
				)),"workTypeWatch");
			}
		},
		
		handleConditionalRequiredPriority: function(eventContext){
			// This is an initialize handler for the WO Details View
			// to handle changes made to the worktype field 
			// and make the Priority field required
			
			// current workOrder is on the eventContext
			var currWO = eventContext.getResource().getCurrentRecord();
			var worktype = currWO.get('worktype');
			
			// Makes the priority field required if worktype equals EMERGENCY
			currWO.getRuntimeFieldMetadata('priority').set('required', worktype && worktype=="EM"); 
							
			// Hook a listener to watch the worktype attribute, 
			// and make the priority attribute required when the worktype is Emergency
		 	eventContext.addResourceWatchHandle(currWO.watch('worktype',
				lang.hitch(this, function(attrName, oldValue, newValue)
						{
							currWO.getRuntimeFieldMetadata('priority').set('required', newValue && newValue=="EM"); 
						}
			)));

		
	});
});