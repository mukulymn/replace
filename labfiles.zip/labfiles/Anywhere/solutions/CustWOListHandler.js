define("custom/handlers/CustWOListHandler",
	["dojo/_base/declare",
	"platform/handlers/_ApplicationHandlerBase",
	"platform/model/ModelService",
	"platform/util/DateTimeUtil",
	"platform/logging/Logger",
	"application/business/WorkOrderObject"],

	function(declare, ApplicationHandlerBase, ModelService, DateTimeUtil, Logger, WorkOrderObject) {
	return declare( [ApplicationHandlerBase], {
		changeStatus : function(eventContext) {
			Logger.trace("[CustWOListHandler] Button clicked");
			var statusDate = eventContext.application.getCurrentDateTime();
			statusDate = DateTimeUtil.zeroSecondsAndMilliseconds(statusDate);
			var woSet = eventContext.application.getResource("workOrder");
			for(var i=0; i<woSet.count(); i++) {
			
				var currWo = woSet.getRecordAt(i);
				if(currWo.get("selected")) {
					Logger.trace("[CustWOListHandler] Starting " + currWo.get("wonum"));
					
					WorkOrderObject.changeStatus(currWo, "COMP", statusDate, null, null);
					
					currWo.set("selected", false);
				}
			}
			ModelService.save(woSet);
		},
	});
});