define("custom/handlers/WODetailExtensionHandler", 
	   		[ "dojo/_base/declare",
	     		"dojo/_base/lang",
	     		"platform/handlers/_ApplicationHandlerBase",	  
	     		"application/handlers/CommonHandler"],
function(declare, lang, ApplicationHandlerBase, CommonHandler) {
	
	return declare( [ApplicationHandlerBase],  {
		
		
		handleConditionalRisk: function(eventContext){
			// This is an render handler for the WO Details View
			// to handle changes made to the worktype field and show the Risk field
			
			// current workOrder is on the eventContext
			//1 create a variable to get the current workorder
			var currWO = 
			//2 Create a variable to get the current workorder's worktype
			var worktype = 
	
			// The current risk field is on the eventContext
			// to show the risk field if worktype equals to EMERGENCY
			//3 Set the display based on the event contect in which you are operating
			eventContext.??dosomethingHere
				
			// Hook a listener to watch the worktype attribute, 
			// and make the risk field appear when worktype is Emergency
			//4 add a logic step to create a listener to watch the worktype for value change.  Then when worktype 
			//  is set to "EM", change the display on the Risk attribute to display it.



		},
		
		handleConditionalRequiredPriority: function(eventContext){
			// This is an initialize handler for the WO Details View
			// to handle changes made to the worktype field 
			// and make the Priority field required
			
			// current workOrder is on the eventContext
			//1 create a variable to get the current workorder

			
			//2 Create a variable to get the current workorder's worktype

			
			// Makes the priority field required if worktype equals EMERGENCY
			//3 Get the meta data for the Priority field to be able to set it to Required when work type is an emergency

			
			// Hook a listener to watch the worktype attribute, 
			// and make the priority attribute required when the worktype is Emergency
			//4 add a logic step to create a listener to watch the worktype for value change.  Then when worktype 
			//  is set to "EM", change the display on the Risk attribute to display it.

			
		}

	});
});