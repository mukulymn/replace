define("custom/handlers/CustWOListHandler",
	["dojo/_base/declare",
	"platform/handlers/_ApplicationHandlerBase",
	"platform/model/ModelService",
	"platform/util/DateTimeUtil",
	"platform/logging/Logger",
	"application/business/WorkOrderObject"],

	function(declare, ApplicationHandlerBase, ModelService, DateTimeUtil, Logger, WorkOrderObject) {
	return declare( [ApplicationHandlerBase], {
		changeStatus : function(eventContext) {
			Logger.trace("[CustWOListHandler] Button clicked");
			// 1 Declare a variable by getting the curent date and time
			var statusDate = ;
			// 2 reset the variable to just the date and time with no seconds and milliseconds
			statusDate = DateTimeUtil.????      ;
			// 3 create a set of workorders from the current work order resource
			var woSet =       ;
			// 4 Create a for loop and iterate through all the workorders to set the status to COMP and the status date to the variable you set earlier.
			//   Remeber to check the local attribute on the work order set to see it has been selected and only change the status 
			//   if you have selected the workorder.  Also clear the selected attribute by settin it to false.
			for(var i=0; i<woSet.count(); i++) {

				// Add your code here.  Look at the solution if you have trouble with getting this code to perform according to the scenario.

			}
			ModelService.save(woSet);
		},
	});
});