define("custom/handlers/CustWorkLogHandler", 
	  ["dojo/_base/declare", "dojo/_base/lang",
	   "platform/handlers/_ApplicationHandlerBase",
	   "application/business/SynonymDomain"],
function(declare, lang, ApplicationHandlerBase, SynonymDomain) {

return declare( ApplicationHandlerBase, {
		
  initNewWorkLogEntry: function(eventContext) {
			
    // 1 Create a variable to get the current worklog record
	var currWorkLog =   ;
    // 2 Test the worklog for instantiation (i.e. if you do not have a current worklog skip over any code you need to change the worklog type.
	if(//your logical test here) {
      // 3 create a variable and set it to the worklog domain.
	  var domainlogtype = eventContext.application.getResource("domainlogtype");
      // 4 Create a variable for the value of the default domain value for WORK.  HINT: the domain is a synonym domain.
	  var newVal = ;
	  // 5 set the current work log type to the new value for default type of WORK

	  
	  // Remember to check to the solutions if you run into any difficulties.
	  }
  }
});
});
