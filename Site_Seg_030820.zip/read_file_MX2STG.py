import glob
import os
import sys
import cx_Oracle
import re
from pathlib import Path

user = 'stage'
pwd = 'stage'
con_str = 'localhost:1521/max1'

log_folder_loc = './MX2STG_LOGS'

Path(log_folder_loc).mkdir(parents=True, exist_ok=True)

paths = ["./SQL/SITE","./SQL/ORG","./SQL/ORGSITE","./SQL/SYSTEMORGSITE","./SQL/SYSTEMORG"]

file_log_map = {}            
current_obj = ''
cur_cnt = 0

for path in paths:
    for filename in glob.glob(os.path.join(path, '*.sql')):
        print(filename)
        try:
            con = cx_Oracle.connect(user, pwd, con_str, encoding="UTF-8")
            cur = con.cursor()		
            file_log_map = {}            
            current_obj = ''
            cur_cnt = 0
            output_file = False
            with open(os.path.join(os.getcwd(), filename), 'r') as f:
                for line in f:
                    if line.startswith('--'):
                        match_found = re.search('\w+',line)
                        if match_found:
                            current_obj = match_found.group()
                    if line.startswith('Set define off'):
                        continue
                    if line.strip().endswith(';'):
                        ex_line,_,__ = line.rpartition(';')
                        #print(ex_line)
                        try:
                            cur.execute(ex_line)
                            #pass
                        except Exception as e:
                            _, __, exc_tb = sys.exc_info()                            
                            err_msg = "Exception raised in DB Block"+ str(e)+"Line Number is"+ str(exc_tb.tb_lineno)
                            #print("Exception raised in DB Block", e,"Line Number is", exc_tb.tb_lineno)
                            
                            log_list = file_log_map.get(current_obj,[])
                            if len(log_list) == 0 :
                                if bool(file_log_map):
                                    log_list.append('\n'*4+'-'*50+current_obj+'-'*50+'\n'*2)
                                else:
                                    log_list.append('-'*50+current_obj+'-'*50+'\n'*2)
                            log_list.append(err_msg+'\n')    
                            log_list.append(ex_line+'\n'*2)
                            file_log_map[current_obj] = log_list
                            output_file = True
            #output logs to a file
            if output_file:
                output_file_name = filename.replace(path,'')
                output_file_name = output_file_name.replace('.sql','')
                output_file_name += '_log.txt'
                print('output file name is:',output_file_name)
                log_file_list = []
                for tmp_list in list(file_log_map.values()):
                    log_file_list += tmp_list
                
                toc_file = open(log_folder_loc + output_file_name, "w")
                for log_line in log_file_list:
                    toc_file.write(log_line)
                toc_file.close()
        except Exception as e:

            _, __, exc_tb = sys.exc_info()

            print("Exception raised in DB Block", e,
                  "Line Number is", exc_tb.tb_lineno)

        finally:
            if con:
                con.close()
