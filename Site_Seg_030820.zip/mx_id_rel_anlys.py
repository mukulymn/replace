#11.13
import cx_Oracle

import sys

select_query = """SELECT 'SELECT '''||TBNAME||''','''||NAME||''',COUNT(*) FROM MAXRELATIONSHIP WHERE (PARENT ='''||TBNAME||''' OR 
CHILD = '''||TBNAME||''') AND UPPER(WHERECLAUSE) LIKE ''%'||NAME||'%''' FROM (
select TBNAME,NAME from maxsequence where tbname in 
(select objectname from maxobject where siteorgtype in ('SYSTEMORGSITE','ORG','SITE','ORGSITE','SYSTEMORG') and persistent = 1)
order by tbname)"""

#print(select_query)


con = None
out_file = None
fin_cnt = 0
try:

    out_file = open('./mx_id_rel_analysis.sql','w')
    con = cx_Oracle.connect("maximo", "maximo", "localhost:1521/max1", encoding="UTF-8")
    cur = con.cursor()
    cur1 = con.cursor()

    for result in cur.execute(select_query):
        #print(result[0])
        cur1.execute(result[0])
        tbname,name,cnt =  cur1.fetchone()
        #print(result)
        
        
        if cnt > 0:
            fin_cnt += cnt
            out_file.write('-'*50)
            out_file.write(f'{tbname}--{name}--{cnt}\n')
            name = '%'+name+'%'
            out_file.write(f'select * from maxrelationship where (child = {repr(tbname)} or parent = {repr(tbname)}) and upper(whereclause) like {repr(name)}\n\n')            
        
except Exception as e:

    _, __, exc_tb = sys.exc_info()

    print("Exception raised in DB Block", e,
          "Line Number is", exc_tb.tb_lineno)

finally:

    if con:
        con.close()
        print("Finally closing connection")
    if out_file:
        out_file.write(f'Total number of relationships are {fin_cnt}')
        out_file.close()
