Set autocommit off;

select ma.objectname,ma.attributename,ma.maxtype,ms.sequencename,ma.sameasattribute from maxattribute ma
left outer join maxsequence ms on ms.tbname = ma.objectname and ms.name = ma.attributename 
where ma.persistent = 1 and ma.objectname in (
select objectname from maxobject where siteorgtype='SITE' and persistent = 1 )
--and ma.sameasattribute in ('ORGID','SITEID') and attributename not in ('ORGID','SITEID')
order by ma.objectname,ma.attributename;

select count(*) from asset where siteid = 'BEDFORD';

SELEcT STARTTIMEENTERED FROM LABTRANS;

SELECT * FROM MAXATTRIBUTE WHERE objectname = 'LABTRANS' AND ATTRIBUTENAME LIKE '%ENTERED';