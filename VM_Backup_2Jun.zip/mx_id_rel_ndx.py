#11.13
import cx_Oracle

import sys

select_query = """SELECT 'SELECT '''||TBNAME||''','''||NAME||''',COUNT(*) FROM MAXRELATIONSHIP WHERE UPPER(WHERECLAUSE) LIKE ''%'||NAME||'%''' FROM (
select TBNAME,NAME from maxsequence where tbname in 
(select objectname from maxobject where siteorgtype in ('SYSTEMORGSITE','ORG','SITE','ORGSITE','SYSTEMORG') and persistent = 1 and isview = 0)
order by tbname)"""

#print(select_query)


con = None
out_file = None
fin_cnt = 0
try:

    out_file = open('./STG_NDX2.sql','w')
    con = cx_Oracle.connect("maximo", "maximo", "localhost:1521/max1", encoding="UTF-8")
    cur = con.cursor()
    cur1 = con.cursor()
    ndx_counter = {}
    ndx_objattr = {}
    for result in cur.execute(select_query):
        #print(result[0])
        cur1.execute(result[0])
        tbname,name,cnt =  cur1.fetchone()
        #print(result)
        
        
        if cnt > 0:
            fin_cnt += cnt
            #out_file.write('-'*50)
            #out_file.write(f'{tbname}--{name}--{cnt}\n')
            temp_name = '%'+name+'%'
            #out_file.write(f'select * from maxrelationship where upper(whereclause) like {repr(name)}\n')
            #out_file.write('\n\n\n')
            
            #next_query = f'select parent,child from maxrelationship where upper(whereclause) like {repr(temp_name)}'
            
            next_query =( f"SELECT OBJECTNAME,ATTRIBUTENAME FROM MAXATTRIBUTE WHERE ATTRIBUTENAME = {repr(name)} and persistent = 1"
            f" union "
            f"SELECT OBJECTNAME,ATTRIBUTENAME FROM MAXATTRIBUTE WHERE SAMEASATTRIBUTE = {repr(name)} and persistent = 1"
                          )
            
            #print(next_query)
            for temp_result in cur1.execute(next_query):
                rs_obj = temp_result[0]
                rs_attr = temp_result[1]
                cnt = 1
                
                if rs_obj == tbname and rs_attr == name:
                    continue
                
                if ndx_objattr.get(rs_obj):
                    obj_col_list = ndx_objattr.get(rs_obj)
                    if rs_attr in obj_col_list:
                        continue
                    else:
                        obj_col_list.append(rs_attr)
                else:
                    ndx_objattr[rs_obj] = [rs_attr]
                 
                if ndx_counter.get(rs_obj):
                    cnt = ndx_counter.get(rs_obj) + 1
                    ndx_counter[rs_obj] = cnt
                else:
                    ndx_counter[rs_obj] = cnt
                ndx_name = f'{rs_obj}_Z{cnt}'
                out_file.write(f'CREATE INDEX {ndx_name} on {rs_obj}({rs_attr});\n')
        
except Exception as e:

    _, __, exc_tb = sys.exc_info()

    print("Exception raised in DB Block", e,
          "Line Number is", exc_tb.tb_lineno)

finally:

    if con:
        con.close()
        print("Finally closing connection")
    if out_file:
        #out_file.write(f'Total number of relationships are {fin_cnt}')
        out_file.close()
