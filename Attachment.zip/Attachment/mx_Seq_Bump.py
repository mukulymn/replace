#11.13
import cx_Oracle

import sys

select_query = "select TBNAME,NAME,SEQUENCENAME from maxsequence"

#print(select_query)


con = None
out_file = None
fin_cnt = 0
error_seq = []
try:

    out_file = open('./mx_seq_bump.sql','w')
    con = cx_Oracle.connect("maximo", "maximo", "localhost:1521/max1", encoding="UTF-8")
    cur = con.cursor()
    cur1 = con.cursor()     
    for result in cur.execute(select_query):        
        tbname,name,seq =  result
        
        max_id_query = f"select max({name}) from {tbname}"
        seq_nxt_val_query = f"select {seq}.NEXTVAL from dual"
        diff = 0
        try:
            tbid = cur1.execute(max_id_query).fetchone()
            seqid = cur1.execute(seq_nxt_val_query).fetchone()
            diff = tbid[0] - seqid[0]
        
        except Exception as e:
            _, __, exc_tb = sys.exc_info()

            print("Exception raised in DB Block", e,
                  "Line Number is", exc_tb.tb_lineno)
            error_seq.append(f"{tbname},{name},{seq}")
        
        
        if diff > 0:  
            out_file.write(f'ALTER SEQUENCE {seq} INCREMENT BY {diff} ;\n')
            out_file.write(f"select {seq}.NEXTVAL from dual;\n")
            out_file.write(f'ALTER SEQUENCE {seq} INCREMENT BY 1;\n')
    for err in error_seq:
        out_file.write('--'+err+'\n')
except Exception as e:

    _, __, exc_tb = sys.exc_info()

    print("Exception raised in DB Block", e,
          "Line Number is", exc_tb.tb_lineno)

finally:

    if con:
        con.close()
        print("Finally closing connection")
    if out_file:
        #out_file.write(f'Total number of relationships are {fin_cnt}')
        out_file.close()
