--------------------------------------------------ADDRESS--ADDRESSID--1
select * from maxrelationship where (child = 'ADDRESS' or parent = 'ADDRESS') and upper(whereclause) like '%ADDRESSID%'



--------------------------------------------------AMCREWT--AMCREWTID--2
select * from maxrelationship where (child = 'AMCREWT' or parent = 'AMCREWT') and upper(whereclause) like '%AMCREWTID%'



--------------------------------------------------ASSET--ASSETID--33
select * from maxrelationship where (child = 'ASSET' or parent = 'ASSET') and upper(whereclause) like '%ASSETID%'



--------------------------------------------------ASSET--ASSETUID--10
select * from maxrelationship where (child = 'ASSET' or parent = 'ASSET') and upper(whereclause) like '%ASSETUID%'



--------------------------------------------------ASSETATTRIBUTE--ASSETATTRIBUTEID--1
select * from maxrelationship where (child = 'ASSETATTRIBUTE' or parent = 'ASSETATTRIBUTE') and upper(whereclause) like '%ASSETATTRIBUTEID%'



--------------------------------------------------ASSETFEATURE--ASSETFEATUREID--55
select * from maxrelationship where (child = 'ASSETFEATURE' or parent = 'ASSETFEATURE') and upper(whereclause) like '%ASSETFEATUREID%'



--------------------------------------------------ASSETFEATURESPEC--ASSETFEATURESPECID--1
select * from maxrelationship where (child = 'ASSETFEATURESPEC' or parent = 'ASSETFEATURESPEC') and upper(whereclause) like '%ASSETFEATURESPECID%'



--------------------------------------------------ASSETSPEC--ASSETSPECID--1
select * from maxrelationship where (child = 'ASSETSPEC' or parent = 'ASSETSPEC') and upper(whereclause) like '%ASSETSPECID%'



--------------------------------------------------ASSIGNMENT--ASSIGNMENTID--9
select * from maxrelationship where (child = 'ASSIGNMENT' or parent = 'ASSIGNMENT') and upper(whereclause) like '%ASSIGNMENTID%'



--------------------------------------------------BIMATTRIBUTEMAP--BIMATTRIBUTEMAPID--2
select * from maxrelationship where (child = 'BIMATTRIBUTEMAP' or parent = 'BIMATTRIBUTEMAP') and upper(whereclause) like '%BIMATTRIBUTEMAPID%'



--------------------------------------------------BIMFILTER--BIMFILTERID--1
select * from maxrelationship where (child = 'BIMFILTER' or parent = 'BIMFILTER') and upper(whereclause) like '%BIMFILTERID%'



--------------------------------------------------BIMLMVMODEL--BIMLMVMODELID--4
select * from maxrelationship where (child = 'BIMLMVMODEL' or parent = 'BIMLMVMODEL') and upper(whereclause) like '%BIMLMVMODELID%'



--------------------------------------------------BIMOMNICLASSIMPORT--BIMOMNICLASSIMPORTID--1
select * from maxrelationship where (child = 'BIMOMNICLASSIMPORT' or parent = 'BIMOMNICLASSIMPORT') and upper(whereclause) like '%BIMOMNICLASSIMPORTID%'



--------------------------------------------------BIMPRODUCTPART--BIMPRODUCTPARTID--1
select * from maxrelationship where (child = 'BIMPRODUCTPART' or parent = 'BIMPRODUCTPART') and upper(whereclause) like '%BIMPRODUCTPARTID%'



--------------------------------------------------BIMPROJECT--BIMPROJECTID--12
select * from maxrelationship where (child = 'BIMPROJECT' or parent = 'BIMPROJECT') and upper(whereclause) like '%BIMPROJECTID%'



--------------------------------------------------BIMTYPEMAP--BIMTYPEMAPID--1
select * from maxrelationship where (child = 'BIMTYPEMAP' or parent = 'BIMTYPEMAP') and upper(whereclause) like '%BIMTYPEMAPID%'



--------------------------------------------------BUDGET--BUDGETID--1
select * from maxrelationship where (child = 'BUDGET' or parent = 'BUDGET') and upper(whereclause) like '%BUDGETID%'



--------------------------------------------------BUILDINGMODEL--BUILDINGMODELID--3
select * from maxrelationship where (child = 'BUILDINGMODEL' or parent = 'BUILDINGMODEL') and upper(whereclause) like '%BUILDINGMODELID%'



--------------------------------------------------CALENDAR--CALENDARID--2
select * from maxrelationship where (child = 'CALENDAR' or parent = 'CALENDAR') and upper(whereclause) like '%CALENDARID%'



--------------------------------------------------CLASSSPEC--CLASSSPECID--15
select * from maxrelationship where (child = 'CLASSSPEC' or parent = 'CLASSSPEC') and upper(whereclause) like '%CLASSSPECID%'



--------------------------------------------------CLASSSTRUCTURE--CLASSSTRUCTUREUID--2
select * from maxrelationship where (child = 'CLASSSTRUCTURE' or parent = 'CLASSSTRUCTURE') and upper(whereclause) like '%CLASSSTRUCTUREUID%'



--------------------------------------------------COMPANIES--COMPANIESID--2
select * from maxrelationship where (child = 'COMPANIES' or parent = 'COMPANIES') and upper(whereclause) like '%COMPANIESID%'



--------------------------------------------------CONTRACT--CONTRACTID--14
select * from maxrelationship where (child = 'CONTRACT' or parent = 'CONTRACT') and upper(whereclause) like '%CONTRACTID%'



--------------------------------------------------CONTRACTLINE--CONTRACTLINEID--16
select * from maxrelationship where (child = 'CONTRACTLINE' or parent = 'CONTRACTLINE') and upper(whereclause) like '%CONTRACTLINEID%'



--------------------------------------------------CRAFT--CRAFTID--3
select * from maxrelationship where (child = 'CRAFT' or parent = 'CRAFT') and upper(whereclause) like '%CRAFTID%'



--------------------------------------------------DEPRECIATION--DEPRECIATIONID--1
select * from maxrelationship where (child = 'DEPRECIATION' or parent = 'DEPRECIATION') and upper(whereclause) like '%DEPRECIATIONID%'



--------------------------------------------------FAILURECODE--FAILURECODEID--1
select * from maxrelationship where (child = 'FAILURECODE' or parent = 'FAILURECODE') and upper(whereclause) like '%FAILURECODEID%'



--------------------------------------------------FAILURELIST--FAILURELIST--7
select * from maxrelationship where (child = 'FAILURELIST' or parent = 'FAILURELIST') and upper(whereclause) like '%FAILURELIST%'



--------------------------------------------------HAZARD--HAZARDUID--1
select * from maxrelationship where (child = 'HAZARD' or parent = 'HAZARD') and upper(whereclause) like '%HAZARDUID%'



--------------------------------------------------INSPFIELDRESULT--INSPFIELDRESULTID--1
select * from maxrelationship where (child = 'INSPFIELDRESULT' or parent = 'INSPFIELDRESULT') and upper(whereclause) like '%INSPFIELDRESULTID%'



--------------------------------------------------INSPRESULTSTATUS--INSPRESULTSTATUSID--1
select * from maxrelationship where (child = 'INSPRESULTSTATUS' or parent = 'INSPRESULTSTATUS') and upper(whereclause) like '%INSPRESULTSTATUSID%'



--------------------------------------------------INVENTORY--INVENTORYID--1
select * from maxrelationship where (child = 'INVENTORY' or parent = 'INVENTORY') and upper(whereclause) like '%INVENTORYID%'



--------------------------------------------------INVOICE--INVOICEID--5
select * from maxrelationship where (child = 'INVOICE' or parent = 'INVOICE') and upper(whereclause) like '%INVOICEID%'



--------------------------------------------------INVOICELINE--INVOICELINEID--3
select * from maxrelationship where (child = 'INVOICELINE' or parent = 'INVOICELINE') and upper(whereclause) like '%INVOICELINEID%'



--------------------------------------------------INVRESERVE--REQUESTNUM--8
select * from maxrelationship where (child = 'INVRESERVE' or parent = 'INVRESERVE') and upper(whereclause) like '%REQUESTNUM%'



--------------------------------------------------INVUSE--INVUSEID--4
select * from maxrelationship where (child = 'INVUSE' or parent = 'INVUSE') and upper(whereclause) like '%INVUSEID%'



--------------------------------------------------INVUSELINE--INVUSELINEID--12
select * from maxrelationship where (child = 'INVUSELINE' or parent = 'INVUSELINE') and upper(whereclause) like '%INVUSELINEID%'



--------------------------------------------------INVUSELINESPLIT--INVUSELINESPLITID--3
select * from maxrelationship where (child = 'INVUSELINESPLIT' or parent = 'INVUSELINESPLIT') and upper(whereclause) like '%INVUSELINESPLITID%'



--------------------------------------------------JOBPLAN--JOBPLANID--15
select * from maxrelationship where (child = 'JOBPLAN' or parent = 'JOBPLAN') and upper(whereclause) like '%JOBPLANID%'



--------------------------------------------------LABOR--LABORID--1
select * from maxrelationship where (child = 'LABOR' or parent = 'LABOR') and upper(whereclause) like '%LABORID%'



--------------------------------------------------LABTRANS--LABTRANSID--1
select * from maxrelationship where (child = 'LABTRANS' or parent = 'LABTRANS') and upper(whereclause) like '%LABTRANSID%'



--------------------------------------------------LOCATIONS--LOCATIONSID--14
select * from maxrelationship where (child = 'LOCATIONS' or parent = 'LOCATIONS') and upper(whereclause) like '%LOCATIONSID%'



--------------------------------------------------LOCKOUT--LOCKOUTID--5
select * from maxrelationship where (child = 'LOCKOUT' or parent = 'LOCKOUT') and upper(whereclause) like '%LOCKOUTID%'



--------------------------------------------------LOCMETERREADING--METERREADINGID--1
select * from maxrelationship where (child = 'LOCMETERREADING' or parent = 'LOCMETERREADING') and upper(whereclause) like '%METERREADINGID%'



--------------------------------------------------LOCSYSTEM--LOCSYSTEMID--1
select * from maxrelationship where (child = 'LOCSYSTEM' or parent = 'LOCSYSTEM') and upper(whereclause) like '%LOCSYSTEMID%'



--------------------------------------------------MATRECTRANS--MATRECTRANSID--18
select * from maxrelationship where (child = 'MATRECTRANS' or parent = 'MATRECTRANS') and upper(whereclause) like '%MATRECTRANSID%'



--------------------------------------------------MATUSETRANS--MATUSETRANSID--2
select * from maxrelationship where (child = 'MATUSETRANS' or parent = 'MATUSETRANS') and upper(whereclause) like '%MATUSETRANSID%'



--------------------------------------------------MEASUREMENT--MEASUREMENTID--1
select * from maxrelationship where (child = 'MEASUREMENT' or parent = 'MEASUREMENT') and upper(whereclause) like '%MEASUREMENTID%'



--------------------------------------------------MEASUREPOINT--MEASUREPOINTID--2
select * from maxrelationship where (child = 'MEASUREPOINT' or parent = 'MEASUREPOINT') and upper(whereclause) like '%MEASUREPOINTID%'



--------------------------------------------------METERREADING--METERREADINGID--1
select * from maxrelationship where (child = 'METERREADING' or parent = 'METERREADING') and upper(whereclause) like '%METERREADINGID%'



--------------------------------------------------MR--MRID--3
select * from maxrelationship where (child = 'MR' or parent = 'MR') and upper(whereclause) like '%MRID%'



--------------------------------------------------MRLINE--MRLINEID--5
select * from maxrelationship where (child = 'MRLINE' or parent = 'MRLINE') and upper(whereclause) like '%MRLINEID%'



--------------------------------------------------MULTIASSETLOCCI--MULTIID--12
select * from maxrelationship where (child = 'MULTIASSETLOCCI' or parent = 'MULTIASSETLOCCI') and upper(whereclause) like '%MULTIID%'



--------------------------------------------------PLUSCTEMPLATE--PLUSCTEMPLATEID--1
select * from maxrelationship where (child = 'PLUSCTEMPLATE' or parent = 'PLUSCTEMPLATE') and upper(whereclause) like '%PLUSCTEMPLATEID%'



--------------------------------------------------PLUSDSPLAN--PLUSDSPLANID--3
select * from maxrelationship where (child = 'PLUSDSPLAN' or parent = 'PLUSDSPLAN') and upper(whereclause) like '%PLUSDSPLANID%'



--------------------------------------------------PM--PMUID--4
select * from maxrelationship where (child = 'PM' or parent = 'PM') and upper(whereclause) like '%PMUID%'



--------------------------------------------------PO--POID--7
select * from maxrelationship where (child = 'PO' or parent = 'PO') and upper(whereclause) like '%POID%'



--------------------------------------------------POLINE--POLINEID--10
select * from maxrelationship where (child = 'POLINE' or parent = 'POLINE') and upper(whereclause) like '%POLINEID%'



--------------------------------------------------PR--PRID--7
select * from maxrelationship where (child = 'PR' or parent = 'PR') and upper(whereclause) like '%PRID%'



--------------------------------------------------PRECAUTION--PRECAUTIONUID--1
select * from maxrelationship where (child = 'PRECAUTION' or parent = 'PRECAUTION') and upper(whereclause) like '%PRECAUTIONUID%'



--------------------------------------------------PRLINE--PRLINEID--5
select * from maxrelationship where (child = 'PRLINE' or parent = 'PRLINE') and upper(whereclause) like '%PRLINEID%'



--------------------------------------------------QUALIFICATION--QUALIFICATIONUID--1
select * from maxrelationship where (child = 'QUALIFICATION' or parent = 'QUALIFICATION') and upper(whereclause) like '%QUALIFICATIONUID%'



--------------------------------------------------RFQ--RFQID--5
select * from maxrelationship where (child = 'RFQ' or parent = 'RFQ') and upper(whereclause) like '%RFQID%'



--------------------------------------------------RFQLINE--RFQLINEID--5
select * from maxrelationship where (child = 'RFQLINE' or parent = 'RFQLINE') and upper(whereclause) like '%RFQLINEID%'



--------------------------------------------------ROUTES--ROUTESID--2
select * from maxrelationship where (child = 'ROUTES' or parent = 'ROUTES') and upper(whereclause) like '%ROUTESID%'



--------------------------------------------------SAFETYLEXICON--SAFETYLEXICONID--4
select * from maxrelationship where (child = 'SAFETYLEXICON' or parent = 'SAFETYLEXICON') and upper(whereclause) like '%SAFETYLEXICONID%'



--------------------------------------------------SAFETYPLAN--SAFETYPLANUID--1
select * from maxrelationship where (child = 'SAFETYPLAN' or parent = 'SAFETYPLAN') and upper(whereclause) like '%SAFETYPLANUID%'



--------------------------------------------------SERVICEADDRESS--SERVICEADDRESSID--1
select * from maxrelationship where (child = 'SERVICEADDRESS' or parent = 'SERVICEADDRESS') and upper(whereclause) like '%SERVICEADDRESSID%'



--------------------------------------------------SERVRECTRANS--SERVRECTRANSID--8
select * from maxrelationship where (child = 'SERVRECTRANS' or parent = 'SERVRECTRANS') and upper(whereclause) like '%SERVRECTRANSID%'



--------------------------------------------------SHIFT--SHIFTID--1
select * from maxrelationship where (child = 'SHIFT' or parent = 'SHIFT') and upper(whereclause) like '%SHIFTID%'



--------------------------------------------------SHIPMENT--SHIPMENTID--2
select * from maxrelationship where (child = 'SHIPMENT' or parent = 'SHIPMENT') and upper(whereclause) like '%SHIPMENTID%'



--------------------------------------------------SLROUTE--SLROUTEID--1
select * from maxrelationship where (child = 'SLROUTE' or parent = 'SLROUTE') and upper(whereclause) like '%SLROUTEID%'



--------------------------------------------------SPWORKASSET--SPWORKASSETID--3
select * from maxrelationship where (child = 'SPWORKASSET' or parent = 'SPWORKASSET') and upper(whereclause) like '%SPWORKASSETID%'



--------------------------------------------------TAGOUT--TAGOUTUID--1
select * from maxrelationship where (child = 'TAGOUT' or parent = 'TAGOUT') and upper(whereclause) like '%TAGOUTUID%'



--------------------------------------------------WORKORDER--WORKORDERID--20
select * from maxrelationship where (child = 'WORKORDER' or parent = 'WORKORDER') and upper(whereclause) like '%WORKORDERID%'



--------------------------------------------------WORKPERIOD--WORKPERIODID--1
select * from maxrelationship where (child = 'WORKPERIOD' or parent = 'WORKPERIOD') and upper(whereclause) like '%WORKPERIODID%'



--------------------------------------------------WOTASKRELATION--WOTASKRELATIONID--3
select * from maxrelationship where (child = 'WOTASKRELATION' or parent = 'WOTASKRELATION') and upper(whereclause) like '%WOTASKRELATIONID%'



Total number of relationships are 420